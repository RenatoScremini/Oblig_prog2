package Heap;

public class EmptyHeap  extends Exception{
}
