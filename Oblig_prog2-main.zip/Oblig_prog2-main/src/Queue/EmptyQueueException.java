package Queue;

public class EmptyQueueException extends Exception{
}
