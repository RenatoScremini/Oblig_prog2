package ExceptionsTads;

public class ArbolLLeno extends Exception{
}
