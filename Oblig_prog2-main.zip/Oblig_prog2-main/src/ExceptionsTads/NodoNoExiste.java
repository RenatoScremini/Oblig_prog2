package ExceptionsTads;

public class NodoNoExiste extends Exception{
}
