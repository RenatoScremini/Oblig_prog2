package ExceptionsTads;

public class NodoOcupado extends Exception{
}
