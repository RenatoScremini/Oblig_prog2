package ExceptionsTads;

public class NumeroInvalido extends Exception{
}
